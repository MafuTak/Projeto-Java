import java.util.Scanner;

public class SistemaEstoque {
    public static void main(String[] args) {
        Estoque estoque = new Estoque();
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("=== Sistema de Estoque ===");
            System.out.println("1. Cadastrar Produto");
            System.out.println("2. Entrada de Produto");
            System.out.println("3. Saída de Produto");
            System.out.println("4. Listar Produtos");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("1. Cadastrar Acessório de Segurança");
                    System.out.println("2. Cadastrar Acessório de Uso");
                    System.out.print("Escolha o tipo de acessório: ");
                    int tipoAcessorio = scanner.nextInt();

                    System.out.print("ID do Produto: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Nome do Produto: ");
                    String nome = scanner.nextLine();
                    System.out.print("Preço do Produto: ");
                    double preco = scanner.nextDouble();
                    System.out.print("Quantidade inicial em estoque: ");
                    int quantidade = scanner.nextInt();

                    Produto produto;
                    if (tipoAcessorio == 1) {
                        produto = new AcessorioSeguranca(id, nome, preco, quantidade);
                    } else {
                        produto = new AcessorioUso(id, nome, preco, quantidade);
                    }
                    estoque.adicionarProduto(produto);
                    break;

                case 2:
                    System.out.print("ID do Produto para entrada: ");
                    int idEntrada = scanner.nextInt();
                    System.out.print("Quantidade a adicionar: ");
                    int quantidadeEntrada = scanner.nextInt();
                    System.out.print("Tipo do Produto (1 - Segurança, 2 - Uso): ");
                    int tipoEntrada = scanner.nextInt();
                    estoque.entradaProduto(idEntrada, quantidadeEntrada, tipoEntrada);
                    break;

                case 3:
                    System.out.print("ID do Produto para saída: ");
                    int idSaida = scanner.nextInt();
                    System.out.print("Quantidade a remover: ");
                    int quantidadeSaida = scanner.nextInt();
                    System.out.print("Tipo do Produto (1 - Segurança, 2 - Uso): ");
                    int tipoSaida = scanner.nextInt();
                    estoque.saidaProduto(idSaida, quantidadeSaida, tipoSaida);
                    break;

                case 4:
                    System.out.println("1. Listar Acessórios de Segurança");
                    System.out.println("2. Listar Acessórios de Uso");
                    System.out.print("Escolha o tipo de acessório para listar: ");
                    int tipoListar = scanner.nextInt();
                    estoque.listarProdutosPorTipo(tipoListar);
                    break;

                case 5:
                    System.out.println("Encerrando o sistema...");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 5);

        scanner.close();
    }
}
