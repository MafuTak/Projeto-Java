public class AcessorioUso extends Produto {
    public AcessorioUso(int idProduto, String nome, double preco, int quantidade) {
        super(idProduto, nome, preco, quantidade);
    }
}
