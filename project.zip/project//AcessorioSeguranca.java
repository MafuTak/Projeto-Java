public class AcessorioSeguranca extends Produto {
    public AcessorioSeguranca(int idProduto, String nome, double preco, int quantidade) {
        super(idProduto, nome, preco, quantidade);
    }
}
