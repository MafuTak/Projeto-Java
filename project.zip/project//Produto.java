public class Produto {
    private int idProduto;
    private String nome;
    private double preco;
    private int quantidade;

    public Produto(int idProduto, String nome, double preco, int quantidade) {
        this.idProduto = idProduto;
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
    }

    public int getIdProduto() {
        return idProduto;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void adicionarEstoque(int quantidade) {
        this.quantidade += quantidade;
    }

    public void removerEstoque(int quantidade) {
        if (this.quantidade >= quantidade) {
            this.quantidade -= quantidade;
        } else {
            System.out.println("Quantidade em estoque insuficiente.");
        }
    }

    @Override
    public String toString() {
        return "ID: " + idProduto + " | Nome: " + nome + " | Preço: " + preco + " | Quantidade: " + quantidade;
    }
}
