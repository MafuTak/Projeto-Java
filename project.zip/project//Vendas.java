import java.util.ArrayList;
import java.util.List;

public class Vendas {
    private List<ItemVendidos> itensVendidos;

    public Vendas() {
        itensVendidos = new ArrayList<>();
    }

    public void adicionarItemVenda(ItemVendidos item) {
        itensVendidos.add(item);
    }

    public void listarVendas() {
        if (itensVendidos.isEmpty()) {
            System.out.println("Nenhuma venda realizada.");
        } else {
            for (ItemVendidos item : itensVendidos) {
                System.out.println(item);
            }
        }
    }

    public double calcularTotalVendas() {
        double total = 0;
        for (ItemVendidos item : itensVendidos) {
            total += item.getTotalVenda();
        }
        return total;
    }
}
